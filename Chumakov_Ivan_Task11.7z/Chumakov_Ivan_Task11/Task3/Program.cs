﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_2;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {           
            List<Point> arr = new List<Point>();
            for (int i = 0; i < 1000; i++)
            {
                for (int j = 0; j < 1000; j++)
                {
                    arr.Add(new Point(i.GetHashCode(), j.GetHashCode()));
                }               
            }
            foreach (var item in arr)
            {
                Console.WriteLine(arr.GetHashCode());
            }

            Console.ReadKey();
        }
    }
}
