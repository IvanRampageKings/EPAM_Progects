﻿using System;

namespace Task_2
{
    public class Point
    {
        int x;
        int y;


        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }
        public override int GetHashCode()
        {
            return x.GetHashCode() * 9 + y.GetHashCode();
        }
    }
}
