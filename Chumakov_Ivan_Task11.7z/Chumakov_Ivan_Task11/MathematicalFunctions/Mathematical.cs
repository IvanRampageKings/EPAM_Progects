﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathematicalFunctions
{
    public static class Mathematical
    {
        public static int Factorial(int n)
        {
            if(n <= 1)
            {
                return n;
            }
            else
            {
                return n * Factorial(n - 1);
            }
        }
       public static int Math(this int a, int n)
        {
            int result =1;
            for (int i = 0; i < n; i++)
            {
                result *= a;
            }
            return result;
        }
    }
}
