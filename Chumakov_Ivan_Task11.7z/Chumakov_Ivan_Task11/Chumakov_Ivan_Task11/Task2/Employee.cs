﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class Employee : User, IEquatable<Employee>
	{
		string post = "";
		int workExperience;
		public string Post
		{
			set
			{

				if (post.Length > 50)
				{
					post = "Serf";
				}
				else
				{
					post = value;
				}
			}
			get
			{
				return post;
			}
		}
		int WorkExperience
		{
			set
			{
				if (workExperience < 0)
				{
					workExperience = 0;
				}
			}
			get { return workExperience; }
		}

		public bool Equals(Employee other)
		{
			if (other == null)
			{
				return false;
			}
			else if (Name == other.Name && String.Compare(Post, other.Post, true) == 0 && Surname == other.Surname)
			{
				return true;
			}
			return false;
		}
	}
}
