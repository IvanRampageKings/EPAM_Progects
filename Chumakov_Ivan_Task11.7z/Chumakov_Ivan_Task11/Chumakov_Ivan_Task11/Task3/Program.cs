﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_2;

namespace Task3
{
	class Program
	{
		static void Main(string[] args)
		{
			List<Point> arr = new List<Point>();

			arr.Add(new Point(1, 1));
			arr.Add(new Point(10, 10));

			foreach (var item in arr)
			{
				Console.WriteLine(item.GetHashCode());
			}

			Console.ReadKey();
		}
	}
}
