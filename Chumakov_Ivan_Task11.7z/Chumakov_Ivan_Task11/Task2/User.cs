﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class User
    {
        string name;

        DateTime dateBirth;
        public string Name
        {
            set
            {
                if (value.Length > 20)
                {
                    name = null;
                }
                else
                {
                    name = value;
                }
            }
            get
            {
                return name;
            }
        }

        public string Surname { get; set; }
        public string Patronymic { get; set; }

        public DateTime DateBirth
        {
            set
            {
                bool selector = true;
                DateTime date = DateTime.Now;
                if (value.Year >= date.Year)
                {
                    if (value.Month >= date.Month)
                    {
                        if (value.Day > date.Day)
                        {
                            dateBirth = date;
                            selector = false;
                        }
                    }
                }
                if (selector)
                {
                    dateBirth = value;
                }
            }
            get { return dateBirth; }
        }
        public int Age
        {
            get
            {
                int flag = 0;
                DateTime date = DateTime.Now;
                if (date.Month <= dateBirth.Month)
                {
                    if (date.Day < dateBirth.Day)
                    {
                        flag = -1;
                    }
                }
                return date.Year - dateBirth.Year + flag;
            }
        }
    }
}
