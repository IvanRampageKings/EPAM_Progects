﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task1;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee a = new Employee()
            {
                Name = "a",
                Surname = "f",
                Post = "Director"
            };
            Employee b = new Employee()
            {
                Name = "a",
                Surname = "f",
                Post = "Director"
            };
            Console.WriteLine(a.Equals(b));
           
            Console.ReadKey();
        }
    }
}
