﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Circle : Figure
    {
        double r;
        public double R
        {
            set
            {
                if (value < 0)
                {
                    r = 0;
                }
                else
                {
                    r = value;
                }
            }
        }
        public override void Draw()
        {
            Console.WriteLine("Окружность с радиусом: " + r);
        }
        public Circle()
        {
            r = 0;
        }
        public Circle(double r)
        {
            this.r = r;
        }
    }
}
