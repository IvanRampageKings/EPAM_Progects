﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Rectangle : Figure
    {
        double a, b;
        double A
        {
            set
            {
                if (value < 0)
                {
                    a = 0;
                }
                else
                {
                    a = value;
                }
            }
            get { return a; }
        }
        double B
        {
            set
            {
                if (value < 0)
                {
                    b = 0;
                }
                else
                {
                    b = value;
                }
            }
            get { return b; }
        }
        public override void Draw()
        {
            Console.WriteLine("Прямоугольник со сторонами: " + a + " и " + b);
        }
        public Rectangle()
        {
            a = 0;
            b = 0;
        }
        public Rectangle(double a, double b)
        {
            this.a = a;
            this.b = b;
        }
    }
}
