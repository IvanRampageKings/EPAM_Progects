﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Line : Figure
    {
        double length;
        public double Lenght
        {
            set
            {
                if (value < 0)
                {
                    length = 0;
                }
                else
                {
                    length = value;
                }
            }
            get { return length; }
        }
        public Line CreateLine(double lenght)
        {
            Line line = new Line
            {
                Lenght = length
            };
            return line;
        }
        public override void Draw()
        {
            Console.WriteLine("Линия длинной: "+ length);
        }
        public Line()
        {
            length = 0;
        }
        public Line(double length)
        {
           this.length = length;
        }
    }
}
