﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figure> figure = new List<Figure>
            {
                new Line(5),
                new Circle(10),
                new Rectangle(15, 20)
            };
            foreach (var item in figure)
            {               
                item.Draw();
            }
            Console.ReadKey();
        }       
    }
}
