﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2;

namespace Task3
{
	class Program
	{
		static void Main(string[] args)
		{
			ISeries list = new List(new double[] { 3, 5, 9, 12, 15 });
			PrintSeries(list);
			Console.WriteLine();
			IIndexableSeries progression = new ArithmeticalProgression(2, 4);
			PrintSeries(progression);		
			Console.WriteLine();
			Console.WriteLine(progression[2]);
			Console.ReadKey();
		}
		static void PrintSeries(ISeries series)
		{
			series.Reset();

			for (int i = 0; i < 10; i++)
			{
				Console.WriteLine(series.GetCurrent());
				series.MoveNext();
			}
		}
	}
}
