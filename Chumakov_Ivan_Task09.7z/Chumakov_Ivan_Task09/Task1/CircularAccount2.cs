﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class CircularAccount2
	{
		static LinkedList<int> linkedList = new LinkedList<int>();		
		public static void Fill(int n)
		{
			for (int i = 1; i <= n; i++)
			{
			
			}
		}
		public static void RemoveEachSecondItem()
		{

			bool yes = false;
			for (int i = 0; ; i++)
			{
				if (linkedList.Count == i)
				{
					i = 0;
				}
				if (yes)
				{
					linkedList.Remove(i);
					i--;
					yes = false;
				}
				else
				{
					yes = true;
				}
				if (linkedList.Count == 1)
				{
					Console.WriteLine();
					break;
				}
			}
		}
	}
}
