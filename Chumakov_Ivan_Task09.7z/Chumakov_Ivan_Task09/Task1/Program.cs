﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class Program
	{
		static void Main(string[] args)
		{
			CircularAccount1.Fill(9);
			CircularAccount1.RemoveEachSecondItem();

			CircularAccount2.Fill(9);
			CircularAccount2.RemoveEachSecondItem();
			Console.ReadKey();
		}
	}
}
