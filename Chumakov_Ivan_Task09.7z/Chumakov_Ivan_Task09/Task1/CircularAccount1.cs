﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class CircularAccount1
	{
		static List<int> list = new List<int>();
		public static void Fill(int n)
		{
			for (int i = 1; i <= n; i++)
			{
				list.Add(i);
			}
		}
		public static void RemoveEachSecondItem()
		{
			bool yes = false;
			for (int i = 0; ; i++)
			{
				if (list.Count == i)
				{
					i = 0;
				}
				if (yes)
				{
					list.RemoveAt(i);
					i--;
					yes = false;
				}
				else
				{
					yes = true;
				}
				if (list.Count == 1)
				{
					Console.WriteLine(list[0]);
					break;
				}
			}
		}
	}
}
