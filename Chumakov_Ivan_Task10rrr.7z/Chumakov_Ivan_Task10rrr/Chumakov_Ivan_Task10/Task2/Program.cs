﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            //  MyEvent _event = new MyEvent();
            DateTime data = DateTime.Now;


            Person john = new Person { Name = "John" };
            Person bill = new Person { Name = "Bill" };
            bill.Come += john.Greet;
            bill.OnCome();
            Person hugo = new Person { Name = "Hugo" };
            hugo.Come += john.Greet;
            hugo.Come += bill.Greet;

            hugo.OnCome();

            hugo.Come -= john.Greet;
            hugo.Come -= bill.Greet;
            hugo = null;




            //      var persons = new List<Person> { pers1, pers2, pers3 };


            Console.ReadKey();
        }

        private static void Pers2_Come(Person person, DateTime data)
        {
            throw new NotImplementedException();
        }
    }
}
