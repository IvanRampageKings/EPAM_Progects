﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    //public delegate string[] SortArray(string[] str);
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[]
            {
                "qwe",
                "asdf",
                "zxcvb",
                "nm",
                "as",
                "awe",
                "aqwert"
            };
            //	SortArray sortArray = Sort;
            Sort1(arr, CompareLengthAscending);
            Sort1(arr, CompareLengthDesc);
            //	string[] sortArr = Sort(arr);
            //foreach (var item in sortArr)
            //{
            //	Console.WriteLine(item);
            //}
            Console.ReadKey();
        }


        public static string[] Sort1(string[] array, Func<string, string, int> lengthComparison)
        {
            var lengthComparisonResult = lengthComparison;
            if (lengthComparisonResult == 0)
            {
                if (a == b)
                {
                    return 0;
                }
                else
                {
                    string[] temp = new string[2];
                    temp[0] = a;
                    temp[1] = b;

                    Array.Sort(temp);
                    if (temp[0] == a)
                    {
                        return -1;
                    }
                    else
                    {
                        return 1;
                    }
                }

            }

            return lengthComparisonResult;
        }

        static int CompareLengthAscending(string a, string b)
        {
            return a.Length.CompareTo(b.Length);
            //if (a.Length < b.Length)
            //{
            //    return -1;
            //}
            //else if (a.Length > b.Length)
            //{
            //    return 1;
            //}
        }

        static int CompareLengthDesc(string a, string b)
        {
            return -a.Length.CompareTo(b.Length);
        }

        public static string[] Sort(string[] str)
        {
            //	Array.Sort(str, );

            return str;
        }
    }
}
