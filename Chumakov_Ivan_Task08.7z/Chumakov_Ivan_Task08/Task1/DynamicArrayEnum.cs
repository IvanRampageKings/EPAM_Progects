﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	public class DynamicArrayEnum<T> : IEnumerator where T : new()
	{
		public T[] _dynamicArray;
		int position = -1;
		int length;
		public DynamicArrayEnum(T[] arr, int length)
		{
			_dynamicArray = arr;
			this.length = length;
		}

		object IEnumerator.Current { get { return Current; } }
		public T Current
		{
			get { return _dynamicArray[position]; }
		}

		public bool MoveNext()
		{
			position++;
			return (position < length);
		}

		public void Reset()
		{
			position = -1;
		}
	}
}
