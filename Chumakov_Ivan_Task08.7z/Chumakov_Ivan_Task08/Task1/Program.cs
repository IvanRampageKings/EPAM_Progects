﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class MyClass
	{
	
	}
	class Program
	{
		static void Main(string[] args)
		{
			//DynamicArray<MyClass> my = new DynamicArray<MyClass>();
			//for (int i = 0; i < 3; i++)
			//{
			//	my.Add(new MyClass());
			//}
			//foreach (var item in my)
			//{
			//	Console.WriteLine(item);
			//}
			DynamicArray<int> my2 = new DynamicArray<int>();
			for (int i = 0; i < 5; i++)
			{
				my2.Add(i);
			}
			foreach (var item in my2)
			{
				Console.WriteLine(item);
			}
			Console.WriteLine();
			Console.WriteLine(my2.Capacity + " " + my2.Length);
			Console.WriteLine();
			my2.Insert(20, 5);
			foreach (var item in my2)
			{
				Console.WriteLine(item);
			}
			Console.WriteLine();
			Console.WriteLine(my2.Capacity + " " + my2.Length);
			Console.WriteLine();
			my2.Remove(4);
			foreach (var item in my2)
			{
				Console.WriteLine(item);
			}
			Console.WriteLine();
			Console.WriteLine(my2.Capacity + " " + my2.Length);
			Console.ReadKey();
		}
	}
}
