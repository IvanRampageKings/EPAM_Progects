﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class DynamicArray<T> : IEnumerable where T : new()
	{
		T[] arr;
		public int Length { get; private set; }
		public int Capacity { get; private set; }
		public T this[int i]
		{
			get
			{
				if (i > Capacity)
				{
					throw new ArgumentOutOfRangeException("Выход за границы массива");
				}
				return arr[i];
			}
			set
			{
				if (i > Capacity)
				{
					throw new ArgumentOutOfRangeException("Выход за границы массива");
				}
				arr[i] = value;
			}
		}
		public DynamicArray()
		{
			const int SIZE = 8;
			arr = new T[SIZE];
			Length = 0;
			Capacity = SIZE;
		}
		public DynamicArray(int num)
		{
			arr = new T[num];
			Length = 0;
			Capacity = num;
		}
		public DynamicArray(T[] arr)
		{
			this.arr = arr;
			Length = Capacity = arr.Length;
		}
		public void Add(T element)
		{
			if (Length < arr.Length)
			{
				arr[Length] = element;
				Length++;
			}
			else
			{
				T[] temp = new T[Capacity];
				arr.CopyTo(temp, 0);
				arr = new T[arr.Length * 2];
				temp.CopyTo(arr, 0);
				arr[temp.Length] = element;
				Length++;
				Capacity *= 2;
			}
		}
		public void AddRange(T[] elements)
		{
			if (elements.Length > (Capacity - Length))
			{
				T[] temp = new T[Length];
				arr.CopyTo(temp, 0);
				arr = new T[Length + elements.Length];
				temp.CopyTo(arr, 0);
				elements.CopyTo(arr, Length);
				Length = Capacity = elements.Length + Length;
			}
			else
			{
				elements.CopyTo(arr, Length);
			}
		}
		public bool Remove(int number)
		{
			if (number < Length)
			{
				arr[number] = default;
				return false;
			}
			else
			{
				return false;
			}
		}
		public void Insert(T element, int number)
		{
			if (number > Capacity)
			{
				throw new ArgumentOutOfRangeException("Выход за границы массива");
			}
			T[] temp = new T[Capacity];
			if (Length < Capacity)
			{
				Array.Copy(arr, number, arr, number + 1, Length - number);
				arr[number] = element;
				Length++;
			}
			else
			{
				arr.CopyTo(temp, 0);
				arr = new T[Capacity + 1];
				Array.Copy(temp, 0, arr, 0, number);
				Array.Copy(temp, number, arr, number + 1, Length - number);
				arr[number] = element;
				Length++;
				Capacity++;
			}
		}
		IEnumerator IEnumerable.GetEnumerator()
		{
			return arr.GetEnumerator();
		}
	}
}
