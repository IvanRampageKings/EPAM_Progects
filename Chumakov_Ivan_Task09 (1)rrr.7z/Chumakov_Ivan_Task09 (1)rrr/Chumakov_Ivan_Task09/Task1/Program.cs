﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
	class Program
	{
		static void Main(string[] args)
		{
			//CircularAccount1.Fill(9);
			//CircularAccount1.RemoveEachSecondItem();

			//CircularAccount2.Fill(9);
			//CircularAccount2.RemoveEachSecondItem();

			List<int> list = new List<int>();
			list = Fill(list, 5);
			RemoveEachSecondItem(list);
			Console.WriteLine();
			LinkedList<int> linkedList = new LinkedList<int>();
			linkedList = Fill(linkedList, 5);
			RemoveEachSecondItem(linkedList);

			Console.ReadKey();
		}

		static void RemoveEachSecondItem(ICollection<int> list)
		{
			List<int> temp = new List<int>();
			bool delete = false;
			while (list.Count > 1)
			{
				foreach (var item in list)
				{
					if (delete)
					{
						temp.Add(item);
						delete = false;
					}
					else
					{
						delete = true;
					}
				}
                foreach (var item in temp)
                {
                    list.Remove(item);
                }
                temp.Clear();
                //ForRemoving();
			}
			foreach (var item in list)
			{
				Console.WriteLine(item);
			}
			//void ForRemoving()
			//{
			//	foreach (var item in temp)
			//	{
			//		list.Remove(item);
			//	}
			//	temp.Clear();
			//}
		}
		static List<int> Fill(List<int> list, int n)
		{
			for (int i = 1; i <= n; i++)
			{
				list.Add(i);
			}
			return list;
		}
		static LinkedList<int> Fill(LinkedList<int> list, int n)
		{
			for (int i = 1; i <= n; i++)
			{
				list.AddLast(i);
			}
			return list;
		}
	}
}
