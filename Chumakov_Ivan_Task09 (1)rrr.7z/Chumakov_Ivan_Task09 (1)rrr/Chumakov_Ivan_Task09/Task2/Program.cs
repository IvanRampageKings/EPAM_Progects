﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Task2
{
	class Program
	{
		static void Main(string[] args)
		{
			string pattern = @"[0-9,.-;:]";
			string text = "123ABs dC.DE,456.FGH, IJKL7 89M,NsdO PQ012";
			string[] result = Regex.Split(text, pattern, RegexOptions.IgnoreCase);
			for (int ctr = 0; ctr < result.Length; ctr++)
			{
				Console.Write("{0}", result[ctr]);
				if (ctr < result.Length - 1)
					Console.Write(" ");
			}
			Console.WriteLine();
			Console.ReadKey();
		}
	}
}
