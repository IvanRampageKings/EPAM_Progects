﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {

        static void Main(string[] args)
        {

            List<Person> people = new List<Person>
            {
                new Person { Name = "John" },
                new Person { Name = "Bill" },
                new Person { Name = "Hugo" }
            };


            var office = new Office();
            foreach (var p in people)
            {
                office.AddPerson(p);
            }

            office.LeftPerson(new Person());


            Console.ReadKey();
        }
        public static void PersonCome(Person person, DateTime data)
        {
            Console.WriteLine(person.Name + " came to work!");
        }
        public static void PersonLeft(Person person)
        {
            Console.WriteLine(person.Name + " left work!");
        }
    }

    public class Office
    {
        Person.EventHandlerCome GreetByAll;
        Person.EventHandlerLeft SayGoodBye;

        //private List<Person> _people;

        public void AddPerson(Person p)
        {
            if (GreetByAll != null)
                GreetByAll(p, DateTime.Now);

            GreetByAll += p.Greet;
        }

        public void LeftPerson(Person p)
        {
            if (SayGoodBye == null)
                SayGoodBye(p);
            GreetByAll -= p.Greet;
        }
    }
}
