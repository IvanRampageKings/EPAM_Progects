﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            //  MyEvent _event = new MyEvent();
            DateTime data = DateTime.Now;

            Person john = new Person { Name = "John" };
            Person bill = new Person { Name = "Bill" };
            Person hugo = new Person { Name = "Hugo" };

			john.Come += PersonCome;
			john.OnCome();
			bill.Come += PersonCome;
			bill.Come += john.Greet;
			bill.OnCome();
			hugo.Come += PersonCome;
			hugo.Come += john.Greet;
			hugo.Come += bill.Greet;
			hugo.OnCome();
			bill.Come -= PersonCome;
			bill.Come -= john.Greet;
			bill.Left += PersonLeft;
			bill.Left += john.TellGoodbye;
			bill.Left += hugo.TellGoodbye;
			bill.OnLeft();




			//hugo.Come += john.Greet;
			//hugo.Come += bill.Greet;

			//hugo.OnCome();

			//hugo.Come -= john.Greet;
			//hugo.Come -= bill.Greet;
			//hugo = null;




			//      var persons = new List<Person> { pers1, pers2, pers3 };


			Console.ReadKey();
        }
		public static void PersonCome(Person person, DateTime data)
		{
			Console.WriteLine(person.Name + " came to work!");
		}
		public static void PersonLeft(Person person)
		{
			Console.WriteLine(person.Name + " left work!");
		}
    }
}
